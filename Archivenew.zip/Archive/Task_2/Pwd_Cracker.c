#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <crypt.h>

#define SALT "$6$AS$"
#define PASSWORD_LENGTH 4

// Function to encrypt a given password
char *encryptPassword(const char *password)
{
    return crypt(password, SALT);
}

// Function to check if the encrypted password matches the target
int checkPassword(const char *encryptedPassword, const char *targetPassword)
{
    return strcmp(encryptedPassword, targetPassword) == 0;
}

// Thread function to search for the password
void *searchPassword(void *threadId)
{
    char password[PASSWORD_LENGTH + 1]; // +1 for null terminator
    char encryptedPassword[100];        // Adjust the size based on your needs

    int threadNum = *((int *)threadId);

    for (char c1 = 'A'; c1 <= 'Z'; ++c1)
    {
        for (char c2 = 'A'; c2 <= 'Z'; ++c2)
        {
            for (int num1 = 0; num1 <= 9; ++num1)
            {
                for (int num2 = 0; num2 <= 9; ++num2)
                {
                    sprintf(password, "%c%c%d%d", c1, c2, num1, num2);
                    strcpy(encryptedPassword, encryptPassword(password));

                    if (checkPassword(encryptedPassword, targetPassword))
                    {
                        printf("Password found by Thread %d: %s\n", threadNum, password);
                        pthread_exit(NULL);
                    }
                }
            }
        }
    }

    pthread_exit(NULL);
}

int main()
{
    const char *targetPassword = "YOUR_ENCRYPTED_PASSWORD"; // Replace with the actual encrypted password

    pthread_t threads[4]; // You can adjust the number of threads based on your system
    int threadIds[4];

    for (int i = 0; i < 4; ++i)
    {
        threadIds[i] = i;
        pthread_create(&threads[i], NULL, searchPassword, (void *)&threadIds[i]);
    }

    for (int i = 0; i < 4; ++i)
    {
        pthread_join(threads[i], NULL);
    }

    return 0;
}
